# ChromaWheel

A color-grading video editor for Android: three-way (shadows / midtones / highlights)
grading wheels, exposure/contrast/saturation, and log-footage decode (Sony S-Log3,
Panasonic V-Log, Canon Log 3, ARRI LogC3) -- all applied live while you scrub the video,
then baked into an exported MP4.

This is an **Android Studio project**, not a ready-made `.apk`. The sandbox this was
built in has no Android SDK and no way to install one, so it cannot compile or sign an
APK itself -- Android Studio (free, from Google) does that part. See **Build it** below;
it's a two-step process once Android Studio is installed.

## What's implemented

- **Import**: pick any video from your device via the system file picker (no storage
  permission needed -- it uses the Storage Access Framework).
- **Live preview**: the graded look renders in real time during playback via a custom
  Media3/ExoPlayer GL effect -- what you see while playing is what gets exported.
- **3-way color wheels**: drag inside each wheel to push that tonal range's color (an
  ASC-CDL-style lift/gamma/gain model); the slider under each wheel adjusts that range's
  brightness.
- **Exposure / contrast / saturation** sliders.
- **Log profile picker**: decode S-Log3, V-Log, Canon Log 3, or LogC3 footage back to a
  normal-contrast image before grading, or turn it off for already-Rec.709 footage.
- **Export**: bakes the exact on-screen grade into a new MP4 via Media3 Transformer, with
  a progress bar, written to the app's own external-storage folder, with a **Share**
  button to send it to Photos/Google Drive/etc.

## What's not in this build

- **Trim/cut/multi-clip editing.** This is a color-grading tool for one clip at a time,
  not a timeline editor.
- **Precise colorimetry.** The log decode curves are the manufacturers' published
  formulas (verified numerically while building this -- see `ColorGradeEffect.kt`), but
  there's no gamut mapping, no 3D LUTs, no color management -- just curve decode +
  lift/gamma/gain + a flat gamma-2.2 re-encode. It's built to grade by eye, not to match
  a reference monitor. **Canon Log 3 in particular is a simplified single-curve
  approximation**, not Canon's exact piecewise formula -- I wasn't able to verify Canon's
  real published constants in this session, and would rather tell you that plainly than
  ship numbers I'm not sure of. If you need broadcast-accurate Canon Log 3, swap
  `decodeCLog3()` in `ColorGradeEffect.kt` for Canon's published curve.
- **A compiled, tested `.apk`.** Explained above -- see **Build it**.

## Build it

1. Install [Android Studio](https://developer.android.com/studio) (free).
2. **File → Open**, select the unzipped `ChromaWheel` folder.
3. Let it sync (first sync downloads Gradle + the Android SDK bits it needs --
   takes a few minutes).
4. Plug in an Android phone (API 26 / Android 8.0 or newer) with USB debugging on, or
   start an emulator.
5. Click **Run**.

To get a signed, shareable `.apk`/`.aab` instead of just running it on one device:
**Build → Generate Signed App Bundle / APK** in Android Studio, and follow its signing-key
wizard (one-time setup).

### If the build doesn't come up clean

This project was written entirely without a compiler available to check it against --
there's no Android SDK in the sandbox it was built in. Every file was re-read and
manually traced import-by-import and signature-by-signature, and the Transformer/
EditedMediaItem/export code was checked against Android's own official documentation
pages directly. That said, if Android Studio flags an error, here's where to look first,
most-to-least likely:

1. **`ColorGradeEffect.kt`'s `ColorGradeShaderProgram` class** -- it extends Media3's
   `BaseGlShaderProgram`. I confirmed this class's constructor and the shape of
   `configure()`/`drawFrame()` from multiple independent descriptions of Media3's effect
   pipeline, but couldn't fetch its literal source to check field-for-field. If Android
   Studio complains here, check it against
   `https://developer.android.com/reference/androidx/media3/effect/BaseGlShaderProgram`
   -- it'll almost certainly just be a method name or constructor-arg mismatch, not a
   structural problem.
2. **Media3 version** -- pinned to `1.8.0` in `gradle/libs.versions.toml`. If a newer
   version fixes something or Android Studio suggests an upgrade, that's safe to accept;
   none of the APIs this app uses are new or likely to have changed shape.
3. Everything else was cross-checked against Android's official Transformer guide and
   Media3 release notes while writing it, so it should be solid.

If you hit an error, the fix is almost always small (an import, a renamed parameter) --
paste the error into Claude (or Android Studio's own quick-fix) and it's a quick patch,
not a rewrite.

## Project layout

```
app/src/main/java/com/chromawheel/app/
  MainActivity.kt              Screen layout, video picker, ExoPlayer preview, export flow
  grading/GradeState.kt        The grade's data model (wheels, sliders, log profile)
  grading/ColorGradeEffect.kt  The GL shader: log decode + lift/gamma/gain, as a Media3 effect
  ui/ColorWheel.kt             The draggable color wheel widget
  ui/GradingPanel.kt           Layout of the three wheels + sliders + log-profile chips
```

## Trying a different log curve's math

All four decode curves live in `ColorGradeEffect.kt`'s `FRAGMENT_SHADER` string, each as
its own small GLSL function (`decodeSLog3`, `decodeVLog`, `decodeCLog3`, `decodeLogC3`).
They're plain math, so they're safe to tweak without touching anything else -- just keep
each curve continuous at its branch point if you change the constants (a jump there shows
up as a visible brightness band in graded footage).
