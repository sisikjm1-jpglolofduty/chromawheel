# Add project specific ProGuard rules here.
# This build ships with isMinifyEnabled = false, so these rules are not
# exercised yet -- they're here ready for when you turn R8 shrinking on.

# Media3 does its own keep-rule bundling via consumer-rules, so nothing
# extra is normally required for ExoPlayer / Transformer / Effect classes.
