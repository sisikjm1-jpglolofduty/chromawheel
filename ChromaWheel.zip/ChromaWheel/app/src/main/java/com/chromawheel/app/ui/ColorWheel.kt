package com.chromawheel.app.ui

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.chromawheel.app.grading.WheelValue
import kotlin.math.atan2
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * A single draggable hue/saturation wheel -- one of the three (shadows / midtones /
 * highlights) ranges in a 3-way color grading control. Dragging anywhere inside the wheel
 * sets [WheelValue.tintX]/[tintY]; the dot jumps to wherever the finger lands and tracks it
 * from there, clamped to the wheel's edge. A luma slider for that same range sits underneath.
 */
@Composable
fun ColorWheel(
    value: WheelValue,
    onValueChange: (WheelValue) -> Unit,
    label: String,
    accent: Color,
    modifier: Modifier = Modifier,
    diameter: Dp = 104.dp,
) {
    var boxSizePx by remember { mutableStateOf(IntSize.Zero) }
    val wheelBitmap = remember { generateWheelBitmap() }
    val density = LocalDensity.current

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Box(
            modifier = Modifier
                .size(diameter)
                .onSizeChanged { boxSizePx = it }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            onValueChange(offsetToWheelValue(offset, boxSizePx, value.luma))
                        },
                    ) { change, _ ->
                        change.consume()
                        onValueChange(offsetToWheelValue(change.position, boxSizePx, value.luma))
                    }
                },
        ) {
            Image(
                bitmap = wheelBitmap,
                contentDescription = null,
                modifier = Modifier
                    .size(diameter)
                    .clip(CircleShape),
            )

            val radiusPx = if (boxSizePx.width > 0) boxSizePx.width / 2f else 0f
            val thumbCenterX = radiusPx + value.tintX * radiusPx
            val thumbCenterY = radiusPx - value.tintY * radiusPx
            val thumbDiameterPx = with(density) { 16.dp.toPx() }

            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            (thumbCenterX - thumbDiameterPx / 2f).roundToInt(),
                            (thumbCenterY - thumbDiameterPx / 2f).roundToInt(),
                        )
                    }
                    .size(16.dp)
                    .border(2.dp, Color.White, CircleShape)
                    .background(accent.copy(alpha = 0.9f), CircleShape),
            )
        }

        Text(
            text = label,
            color = Color.White.copy(alpha = 0.8f),
            style = MaterialTheme.typography.labelMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp),
        )

        Slider(
            value = value.luma,
            onValueChange = { onValueChange(value.copy(luma = it)) },
            valueRange = -1f..1f,
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
            ),
            modifier = Modifier
                .size(width = 104.dp, height = 24.dp)
                .padding(top = 4.dp),
        )
    }
}

/**
 * Converts a drag position (px, within the wheel's own bounds) into a [WheelValue],
 * clamping the tint to the wheel's unit circle. Screen Y is flipped so dragging up is
 * treated as the intuitive "positive" direction.
 */
private fun offsetToWheelValue(offset: Offset, sizePx: IntSize, currentLuma: Float): WheelValue {
    if (sizePx.width <= 0 || sizePx.height <= 0) return WheelValue(luma = currentLuma)
    val radius = sizePx.width / 2f
    val dx = (offset.x - radius) / radius
    val dy = (offset.y - radius) / radius
    val magnitude = sqrt(dx * dx + dy * dy)
    val (clampedX, clampedY) = if (magnitude > 1f) (dx / magnitude) to (dy / magnitude) else dx to dy
    return WheelValue(tintX = clampedX, tintY = -clampedY, luma = currentLuma)
}

/**
 * Builds the wheel's hue/saturation background once: hue sweeps around the angle, full
 * saturation at the rim fading to white (unsaturated) at the center, value fixed at 1.
 */
private fun generateWheelBitmap(sizePx: Int = 256): ImageBitmap {
    val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val center = sizePx / 2f
    val hsv = FloatArray(3)
    hsv[2] = 1f
    for (y in 0 until sizePx) {
        val dy = (y - center) / center
        for (x in 0 until sizePx) {
            val dx = (x - center) / center
            val dist = sqrt(dx * dx + dy * dy)
            if (dist <= 1f) {
                val angleDeg = (Math.toDegrees(atan2(dy, dx).toDouble()).toFloat() + 360f) % 360f
                hsv[0] = angleDeg
                hsv[1] = dist.coerceIn(0f, 1f)
                bitmap.setPixel(x, y, AndroidColor.HSVToColor(hsv))
            } else {
                bitmap.setPixel(x, y, AndroidColor.TRANSPARENT)
            }
        }
    }
    return bitmap.asImageBitmap()
}
