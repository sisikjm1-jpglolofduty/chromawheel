package com.chromawheel.app.grading

import android.content.Context
import android.opengl.GLES20
import android.util.Log
import android.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

private const val TAG = "ColorGradeEffect"

/**
 * A Media3 [GlEffect] that bakes [GradeState]'s log decode + 3-way lift/gamma/gain grade into
 * every video frame. Used both for ExoPlayer's live preview (`player.setVideoEffects(...)`) and
 * for Transformer export (`EditedMediaItem.setEffects(...)`) -- the same shader runs in both
 * places, so the exported file always matches what the preview showed.
 *
 * This class and [ColorGradeShaderProgram] only read [gradeState]'s values; they never write to
 * it, so it's safe to keep reusing the same [GradeState] instance the Compose UI is bound to.
 */
@UnstableApi
class ColorGradeEffect(private val gradeState: GradeState) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        return ColorGradeShaderProgram(gradeState, useHdr)
    }
}

/**
 * The actual per-frame GL pass. [BaseGlShaderProgram] takes care of the input/output texture and
 * framebuffer plumbing for a simple single-frame-in, single-frame-out effect -- all this class
 * has to do is compile its own shader program and, on every [drawFrame], push the current grade
 * as uniforms and draw a full-screen quad.
 *
 * Deliberately implemented with plain `android.opengl.GLES20` calls (shader compile/link,
 * attribute/uniform lookup, a manual vertex buffer) instead of Media3's `GlProgram` convenience
 * wrapper, so every GL call here is the same stable, decade-old Android ES2 API used by any
 * OpenGL tutorial -- nothing here depends on Media3-internal helper-method shapes.
 */
@UnstableApi
private class ColorGradeShaderProgram(
    private val gradeState: GradeState,
    useHdr: Boolean,
) : BaseGlShaderProgram(useHdr, /* texturePoolCapacity= */ 1) {

    private var programId = 0
    private var positionLoc = 0
    private var texCoordLoc = 0
    private var samplerLoc = 0
    private var logProfileLoc = 0
    private var exposureLoc = 0
    private var contrastLoc = 0
    private var saturationLoc = 0
    private var liftLoc = 0
    private var gammaLoc = 0
    private var gainLoc = 0

    private val vertexBuffer: FloatBuffer = directFloatBufferOf(
        // x, y, u, v -- a full-screen triangle strip, standard GL winding.
        floatArrayOf(
            -1f, -1f, 0f, 0f,
            1f, -1f, 1f, 0f,
            -1f, 1f, 0f, 1f,
            1f, 1f, 1f, 1f,
        )
    )

    init {
        programId = linkProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        positionLoc = GLES20.glGetAttribLocation(programId, "aPosition")
        texCoordLoc = GLES20.glGetAttribLocation(programId, "aTexCoord")
        samplerLoc = GLES20.glGetUniformLocation(programId, "uTexSampler")
        logProfileLoc = GLES20.glGetUniformLocation(programId, "uLogProfile")
        exposureLoc = GLES20.glGetUniformLocation(programId, "uExposure")
        contrastLoc = GLES20.glGetUniformLocation(programId, "uContrast")
        saturationLoc = GLES20.glGetUniformLocation(programId, "uSaturation")
        liftLoc = GLES20.glGetUniformLocation(programId, "uLift")
        gammaLoc = GLES20.glGetUniformLocation(programId, "uGamma")
        gainLoc = GLES20.glGetUniformLocation(programId, "uGain")
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        GLES20.glUseProgram(programId)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, inputTexId)
        GLES20.glUniform1i(samplerLoc, 0)

        val cdl = gradeState.toCdlTerms()
        GLES20.glUniform1i(logProfileLoc, gradeState.logProfile.uniformIndex)
        GLES20.glUniform1f(exposureLoc, gradeState.exposure)
        GLES20.glUniform1f(contrastLoc, gradeState.contrast)
        GLES20.glUniform1f(saturationLoc, gradeState.saturation)
        GLES20.glUniform3fv(liftLoc, 1, cdl.lift, 0)
        GLES20.glUniform3fv(gammaLoc, 1, cdl.gamma, 0)
        GLES20.glUniform3fv(gainLoc, 1, cdl.gain, 0)

        vertexBuffer.position(0)
        GLES20.glEnableVertexAttribArray(positionLoc)
        GLES20.glVertexAttribPointer(positionLoc, 2, GLES20.GL_FLOAT, false, 16, vertexBuffer)

        vertexBuffer.position(2)
        GLES20.glEnableVertexAttribArray(texCoordLoc)
        GLES20.glVertexAttribPointer(texCoordLoc, 2, GLES20.GL_FLOAT, false, 16, vertexBuffer)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(positionLoc)
        GLES20.glDisableVertexAttribArray(texCoordLoc)

        val error = GLES20.glGetError()
        if (error != GLES20.GL_NO_ERROR) {
            Log.w(TAG, "GL error after drawFrame: $error")
        }
    }
}

private fun directFloatBufferOf(values: FloatArray): FloatBuffer {
    return ByteBuffer.allocateDirect(values.size * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(values)
            position(0)
        }
}

private fun compileShader(type: Int, source: String): Int {
    val shader = GLES20.glCreateShader(type)
    GLES20.glShaderSource(shader, source)
    GLES20.glCompileShader(shader)
    val status = IntArray(1)
    GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
    if (status[0] == 0) {
        val log = GLES20.glGetShaderInfoLog(shader)
        GLES20.glDeleteShader(shader)
        error("Could not compile shader $type:\n$log")
    }
    return shader
}

private fun linkProgram(vertexSource: String, fragmentSource: String): Int {
    val vertexShader = compileShader(GLES20.GL_VERTEX_SHADER, vertexSource)
    val fragmentShader = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
    val program = GLES20.glCreateProgram()
    GLES20.glAttachShader(program, vertexShader)
    GLES20.glAttachShader(program, fragmentShader)
    GLES20.glLinkProgram(program)
    val status = IntArray(1)
    GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, status, 0)
    if (status[0] == 0) {
        val log = GLES20.glGetProgramInfoLog(program)
        error("Could not link program:\n$log")
    }
    GLES20.glDeleteShader(vertexShader)
    GLES20.glDeleteShader(fragmentShader)
    return program
}

private const val VERTEX_SHADER = """
    attribute vec4 aPosition;
    attribute vec2 aTexCoord;
    varying vec2 vTexCoord;
    void main() {
      gl_Position = aPosition;
      vTexCoord = aTexCoord;
    }
"""

// Log-to-linear decode curves below use each manufacturer's published OETF^-1 formula. They are
// a practical "de-log for preview/grading" step, not a certified colorimetric pipeline: there is
// no gamut mapping or vendor 3D LUT involved, just curve + lift/gamma/gain + a flat gamma-2.2
// re-encode. Good enough to grade by eye; not a substitute for a mastering-grade LUT pipeline.
private const val FRAGMENT_SHADER = """
    precision mediump float;
    varying vec2 vTexCoord;
    uniform sampler2D uTexSampler;
    uniform int uLogProfile;
    uniform float uExposure;
    uniform float uContrast;
    uniform float uSaturation;
    uniform vec3 uLift;
    uniform vec3 uGamma;
    uniform vec3 uGain;

    float decodeSLog3(float x) {
      if (x >= 0.1673609) {
        return (pow(10.0, (x * 1023.0 - 420.0) / 261.5)) * (0.19) - 0.01;
      } else {
        return (x * 1023.0 - 95.0) * 0.01125 / 76.2102946929;
      }
    }

    float decodeVLog(float x) {
      float b = 0.00873;
      float c = 0.241514;
      float d = 0.598206;
      if (x < 0.181) {
        return (x - 0.125) / 5.6;
      } else {
        return pow(10.0, (x - d) / c) - b;
      }
    }

    // Simplified single-branch approximation (not Canon's exact published piecewise
    // curve -- see the README for details). Fitted so black maps to a small toe value
    // and Canon Log 3's commonly-cited 18%-gray code point (~0.332) decodes to linear
    // 0.18, same reference point the real curve is built around.
    float decodeCLog3(float x) {
      return pow(10.0, (x - 0.635970) / 0.504884) - 0.07;
    }

    float decodeLogC3(float x) {
      float a = 5.555556;
      float b = 0.052272;
      float c = 0.247190;
      float d = 0.385537;
      float e = 5.367655;
      float f = 0.092809;
      if (x > e * 0.010591 + f) {
        return (pow(10.0, (x - d) / c) - b) / a;
      } else {
        return (x - f) / e;
      }
    }

    vec3 decodeLog(vec3 c) {
      if (uLogProfile == 1) {
        return vec3(decodeSLog3(c.r), decodeSLog3(c.g), decodeSLog3(c.b));
      } else if (uLogProfile == 2) {
        return vec3(decodeVLog(c.r), decodeVLog(c.g), decodeVLog(c.b));
      } else if (uLogProfile == 3) {
        return vec3(decodeCLog3(c.r), decodeCLog3(c.g), decodeCLog3(c.b));
      } else if (uLogProfile == 4) {
        return vec3(decodeLogC3(c.r), decodeLogC3(c.g), decodeLogC3(c.b));
      }
      return c;
    }

    void main() {
      vec4 src = texture2D(uTexSampler, vTexCoord);
      vec3 color = src.rgb;

      if (uLogProfile != 0) {
        color = max(decodeLog(color), 0.0);
        color = pow(color, vec3(1.0 / 2.2));
      }

      // Exposure: stops, applied multiplicatively.
      color *= pow(2.0, uExposure);

      // Contrast: pivot around mid-gray.
      color = (color - 0.5) * uContrast + 0.5;

      // Saturation: blend toward Rec.709 luma.
      float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
      color = mix(vec3(luma), color, uSaturation);

      // Three-way lift / gamma / gain (ASC CDL style):
      //   out = (in * gain + lift) ^ (1 / gamma)
      color = clamp(color * uGain + uLift, 0.0, 1.0);
      color = pow(color, 1.0 / uGamma);

      gl_FragColor = vec4(clamp(color, 0.0, 1.0), src.a);
    }
"""
