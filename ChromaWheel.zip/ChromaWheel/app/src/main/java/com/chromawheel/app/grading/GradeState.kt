package com.chromawheel.app.grading

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sqrt

/** Which camera log curve the source footage was recorded in. Each one has a
 * published manufacturer decode curve; [ColorGradeEffect] turns the chosen
 * profile into a shader uniform so the fragment shader can pick the right
 * decode function. */
enum class LogProfile(val label: String, val uniformIndex: Int) {
    NONE("Rec.709 / No log", 0),
    SLOG3("Sony S-Log3", 1),
    VLOG("Panasonic V-Log", 2),
    CLOG3("Canon Log 3", 3),
    LOGC3("ARRI LogC3", 4),
}

/**
 * One 3-way grading wheel's value.
 *
 * [tintX]/[tintY] is the dot's position on the wheel, each in -1f..1f (the
 * wheel's unit circle); [luma] is that range's separate brightness slider,
 * in -1f..1f.
 */
data class WheelValue(
    val tintX: Float = 0f,
    val tintY: Float = 0f,
    val luma: Float = 0f,
) {
    val magnitude: Float get() = sqrt(tintX * tintX + tintY * tintY).coerceAtMost(1f)
}

/**
 * Holds every adjustable grading parameter. This is Compose state (read
 * inside composables it will recompose them as usual), and it is also read
 * directly -- via plain property reads on this same object -- from Media3's
 * GL rendering thread each frame in [ColorGradeEffect]. Compose's snapshot
 * system makes a `mutableStateOf` read from any thread return the latest
 * committed value, so no extra locking or copying is needed to publish
 * slider/wheel changes from the main thread to the render thread.
 */
class GradeState {
    var logProfile by mutableStateOf(LogProfile.NONE)
    var shadows by mutableStateOf(WheelValue())
    var midtones by mutableStateOf(WheelValue())
    var highlights by mutableStateOf(WheelValue())

    /** Stops, roughly -2f..2f. */
    var exposure by mutableFloatStateOf(0f)

    /** Multiplier around the 0.5 pivot, roughly 0.5f..1.5f. */
    var contrast by mutableFloatStateOf(1f)

    /** 0f (grayscale) .. 2f (double saturation), 1f is unchanged. */
    var saturation by mutableFloatStateOf(1f)

    fun resetGrade() {
        shadows = WheelValue()
        midtones = WheelValue()
        highlights = WheelValue()
        exposure = 0f
        contrast = 1f
        saturation = 1f
    }
}

/** Tuning constants for how far each wheel's tint/luma can push its ASC-CDL
 * term. These only affect how strong a full drag/slider feels -- they are
 * safe to retune without touching the shader. */
private const val LIFT_TINT_SCALE = 0.25f
private const val LIFT_LUMA_SCALE = 0.25f
private const val GAIN_TINT_SCALE = 0.5f
private const val GAIN_LUMA_SCALE = 0.5f
private const val GAMMA_TINT_SCALE = 0.6f
private const val GAMMA_LUMA_SCALE = 0.6f

/**
 * Projects a wheel's 2D point onto three color axes 120 degrees apart (red,
 * green, blue) -- the standard way a color-grading wheel UI turns a point
 * into an RGB tint. Returns components roughly in -1f..1f before [strength]
 * is applied.
 */
fun wheelTintToRgb(value: WheelValue, strength: Float): FloatArray {
    val r = value.magnitude
    if (r < 0.0001f) return floatArrayOf(0f, 0f, 0f)
    val angle = atan2(value.tintY, value.tintX)
    val twoThirdsPi = (2.0 * PI / 3.0).toFloat()
    val rAxis = cos(angle)
    val gAxis = cos(angle - twoThirdsPi)
    val bAxis = cos(angle + twoThirdsPi)
    return floatArrayOf(rAxis * r * strength, gAxis * r * strength, bAxis * r * strength)
}

/** The final per-channel ASC-CDL style terms: `out = (in * gain + lift) ^ (1/gamma)`. */
data class CdlTerms(val lift: FloatArray, val gamma: FloatArray, val gain: FloatArray)

fun GradeState.toCdlTerms(): CdlTerms {
    val liftTint = wheelTintToRgb(shadows, LIFT_TINT_SCALE)
    val gainTint = wheelTintToRgb(highlights, GAIN_TINT_SCALE)
    val gammaTint = wheelTintToRgb(midtones, GAMMA_TINT_SCALE)

    val lift = FloatArray(3) { i -> liftTint[i] + shadows.luma * LIFT_LUMA_SCALE }
    val gain = FloatArray(3) { i ->
        (1f + gainTint[i] + highlights.luma * GAIN_LUMA_SCALE).coerceIn(0.2f, 2.0f)
    }
    val gamma = FloatArray(3) { i ->
        (1f + gammaTint[i] + midtones.luma * GAMMA_LUMA_SCALE).coerceIn(0.3f, 3.0f)
    }
    return CdlTerms(lift, gamma, gain)
}
