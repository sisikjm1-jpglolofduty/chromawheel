package com.chromawheel.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import com.chromawheel.app.grading.ColorGradeEffect
import com.chromawheel.app.grading.GradeState
import com.chromawheel.app.ui.GradingPanel
import java.io.File
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private val BackgroundColor = Color(0xFF0E0F13)
private val AccentColor = Color(0xFF6FE3C4)
private val ErrorColor = Color(0xFFE8604C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ChromaWheelApp()
        }
    }
}

/** What's currently happening with a graded export; drives the bottom-of-screen status row. */
private sealed interface ExportState {
    data object Idle : ExportState
    data class Exporting(val progress: Int) : ExportState
    data class Done(val outputFile: File) : ExportState
    data class Failed(val message: String) : ExportState
}

@Composable
private fun ChromaWheelApp() {
    MaterialTheme(colorScheme = darkColorScheme(primary = AccentColor, background = BackgroundColor)) {
        Surface(color = BackgroundColor, modifier = Modifier.fillMaxSize()) {
            val context = LocalContext.current
            val scope = rememberCoroutineScope()

            var videoUri by remember { mutableStateOf<Uri?>(null) }
            var exportState by remember { mutableStateOf<ExportState>(ExportState.Idle) }

            val gradeState = remember { GradeState() }
            val colorGradeEffect = remember { ColorGradeEffect(gradeState) }

            val exoPlayer = remember {
                ExoPlayer.Builder(context).build().apply {
                    repeatMode = Player.REPEAT_MODE_ONE
                }
            }
            DisposableEffect(Unit) {
                onDispose { exoPlayer.release() }
            }

            LaunchedEffect(videoUri) {
                val uri = videoUri ?: return@LaunchedEffect
                exoPlayer.setMediaItem(MediaItem.fromUri(uri))
                exoPlayer.prepare()
                exoPlayer.setVideoEffects(listOf(colorGradeEffect))
                exoPlayer.playWhenReady = true
            }

            val pickVideoLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument(),
            ) { uri ->
                if (uri != null) {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                    videoUri = uri
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .background(Color.Black),
                    contentAlignment = Alignment.Center,
                ) {
                    if (videoUri != null) {
                        AndroidView(
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    player = exoPlayer
                                    useController = true
                                }
                            },
                            modifier = Modifier.fillMaxSize(),
                        )
                    } else {
                        Text(
                            "Import a video to start grading",
                            color = Color.White.copy(alpha = 0.6f),
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Button(onClick = { pickVideoLauncher.launch(arrayOf("video/*")) }) {
                        Text("Import video")
                    }
                    Button(
                        enabled = videoUri != null && exportState !is ExportState.Exporting,
                        onClick = {
                            val uri = videoUri ?: return@Button
                            startExport(
                                context = context,
                                uri = uri,
                                colorGradeEffect = colorGradeEffect,
                                scope = scope,
                                onStateChange = { exportState = it },
                            )
                        },
                    ) {
                        Text("Export graded video")
                    }
                }

                ExportStatusRow(
                    exportState = exportState,
                    onShare = { file -> shareVideo(context, file) },
                )

                GradingPanel(gradeState = gradeState)
            }
        }
    }
}

@Composable
private fun ExportStatusRow(exportState: ExportState, onShare: (File) -> Unit) {
    when (exportState) {
        is ExportState.Exporting -> {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                LinearProgressIndicator(
                    progress = { exportState.progress / 100f },
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Exporting... ${exportState.progress}%", color = Color.White)
            }
        }

        is ExportState.Done -> {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                Text(
                    "Saved: ${exportState.outputFile.name}",
                    color = Color.White,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { onShare(exportState.outputFile) }) {
                    Text("Share")
                }
            }
        }

        is ExportState.Failed -> {
            Text(
                "Export failed: ${exportState.message}",
                color = ErrorColor,
                modifier = Modifier.padding(16.dp),
            )
        }

        ExportState.Idle -> Unit
    }
}

/**
 * Builds an [EditedMediaItem] carrying [colorGradeEffect], starts a [Transformer] export to a
 * fresh file in app-external movies storage, and polls progress on [scope] until it finishes.
 * All Transformer calls stay on [scope]'s dispatcher (Compose's main-thread effect dispatcher),
 * matching Transformer's requirement that one instance only ever be touched from one thread.
 */
private fun startExport(
    context: Context,
    uri: Uri,
    colorGradeEffect: ColorGradeEffect,
    scope: kotlinx.coroutines.CoroutineScope,
    onStateChange: (ExportState) -> Unit,
) {
    onStateChange(ExportState.Exporting(0))

    val outputDir = (context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir)
        .apply { mkdirs() }
    val outputFile = File(outputDir, "chromawheel_${System.currentTimeMillis()}.mp4")

    val editedMediaItem = EditedMediaItem.Builder(MediaItem.fromUri(uri))
        .setEffects(Effects(emptyList(), listOf(colorGradeEffect)))
        .build()

    val transformer = Transformer.Builder(context)
        .addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, result: ExportResult) {
                onStateChange(ExportState.Done(outputFile))
            }

            override fun onError(
                composition: Composition,
                result: ExportResult,
                exception: ExportException,
            ) {
                onStateChange(ExportState.Failed(exception.message ?: "Unknown error"))
            }
        })
        .build()

    transformer.start(editedMediaItem, outputFile.absolutePath)

    scope.launch {
        val progressHolder = ProgressHolder()
        while (isActive) {
            val state = transformer.getProgress(progressHolder)
            if (state == Transformer.PROGRESS_STATE_NOT_STARTED) break
            onStateChange(ExportState.Exporting(progressHolder.progress))
            delay(500)
        }
    }
}

private fun shareVideo(context: Context, file: File) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share graded video"))
}
