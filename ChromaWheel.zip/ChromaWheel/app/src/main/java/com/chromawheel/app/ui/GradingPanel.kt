package com.chromawheel.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.chromawheel.app.grading.GradeState
import com.chromawheel.app.grading.LogProfile
import kotlin.math.roundToInt

/** Accent colors for the three wheels, matching the launcher icon's three rings. */
private val ShadowsAccent = Color(0xFF6FE3C4)
private val MidtonesAccent = Color(0xFFF2C14E)
private val HighlightsAccent = Color(0xFFE8604C)

/**
 * The full set of grading controls: log profile picker, the three 3-way wheels, and the
 * exposure/contrast/saturation sliders. Reads and writes straight through to [gradeState] --
 * every control here is a thin binding, so this composable has no state of its own.
 */
@Composable
fun GradingPanel(gradeState: GradeState, modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(16.dp)) {
        LogProfileSelector(gradeState)

        Spacer(Modifier.height(16.dp))

        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth(),
        ) {
            ColorWheel(
                value = gradeState.shadows,
                onValueChange = { gradeState.shadows = it },
                label = "Shadows",
                accent = ShadowsAccent,
            )
            ColorWheel(
                value = gradeState.midtones,
                onValueChange = { gradeState.midtones = it },
                label = "Midtones",
                accent = MidtonesAccent,
            )
            ColorWheel(
                value = gradeState.highlights,
                onValueChange = { gradeState.highlights = it },
                label = "Highlights",
                accent = HighlightsAccent,
            )
        }

        Spacer(Modifier.height(20.dp))

        LabeledSlider("Exposure", gradeState.exposure, -2f..2f) { gradeState.exposure = it }
        LabeledSlider("Contrast", gradeState.contrast, 0.5f..1.5f) { gradeState.contrast = it }
        LabeledSlider("Saturation", gradeState.saturation, 0f..2f) { gradeState.saturation = it }

        TextButton(onClick = { gradeState.resetGrade() }) {
            Text("Reset grade")
        }
    }
}

@Composable
private fun LogProfileSelector(gradeState: GradeState) {
    val scrollState = rememberScrollState()
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(scrollState),
    ) {
        for (profile in LogProfile.entries) {
            FilterChip(
                selected = gradeState.logProfile == profile,
                onClick = { gradeState.logProfile = profile },
                label = { Text(profile.label) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFF6FE3C4),
                    selectedLabelColor = Color.Black,
                ),
            )
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(label, color = Color.White)
            Text(formatTwoDecimals(value), color = Color.White.copy(alpha = 0.7f))
        }
        Slider(value = value, onValueChange = onValueChange, valueRange = range)
    }
}

/** Rounds to 2 decimal places without touching any locale-sensitive format-string API. */
private fun formatTwoDecimals(value: Float): String {
    val rounded = (value * 100).roundToInt() / 100f
    return rounded.toString()
}
